int flag=append(s,&L);
if (!flag)
    printf("%s exists\n",s.ID);

