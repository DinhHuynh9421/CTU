DaThuc khoitao(){
	DaThuc d;
	d=(struct Node*)malloc(sizeof(struct Node));
	d->Next=NULL;
	return d;
}
