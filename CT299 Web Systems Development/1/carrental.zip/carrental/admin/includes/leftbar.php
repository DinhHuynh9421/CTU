	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i>Trang Chủ</a></li>			
				<li><a href="#"><i class="fa fa-files-o"></i> Hãng Xe</a>
				<ul>
				<li><a href="create-brand.php">Tạo Hãng Mới</a></li>
				<li><a href="manage-brands.php">Quản Lý Hãng Xe</a></li>
				</ul>
				</li>
				<li><a href="#"><i class="fa fa-car"></i>Xe</a>
					<ul>
						<li><a href="post-avehical.php">Thêm Xe Mới</a></li>
						<li><a href="manage-vehicles.php">Quản Lý Xe</a></li>
					</ul>
				</li>

				<li><a href="#"><i class="fa fa-sitemap"></i>Đặt Xe</a>
					<ul>
						<li><a href="new-bookings.php">Đơn Đặt Mới</a></li>
						<li><a href="confirmed-bookings.php">Đơn Đã Duyệt</a></li>
						<li><a href="canceled-bookings.php">Đơn Đã Huỷ</a></li>
					</ul>
				</li>

		

				<li><a href="testimonials.php"><i class="fa fa-table"></i>Quản Lý Đánh Giá</a></li>
				<li><a href="manage-conactusquery.php"><i class="fa fa-desktop"></i>Quản Lý Liên Hệ</a></li>
				<li><a href="reg-users.php"><i class="fa fa-users"></i>Quản Lý Người Dùng</a></li>
			<li><a href="manage-pages.php"><i class="fa fa-files-o"></i>Quản Lý Pages</a></li>
			<li><a href="update-contactinfo.php"><i class="fa fa-files-o"></i>Thay Đổi Thông Tin Liên Hệ</a></li>

			<li><a href="manage-subscribers.php"><i class="fa fa-table"></i>Quản Lý Đăng Ký Ưu Đãi</a></li>
			<li><a href="#"><i class="fa fa-table"></i>Admin bán xe</a></li>

			</ul>
		</nav>